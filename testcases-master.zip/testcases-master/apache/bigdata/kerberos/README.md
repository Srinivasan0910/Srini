bigdata-kerberos-deployment
===========

This project contains some tests which can be used to test kerberos with 
various big data deployments, such as Apache Hadoop etc. The tests use Apache
Kerby to create the KDCs, add principals, write out the keytabs etc.
