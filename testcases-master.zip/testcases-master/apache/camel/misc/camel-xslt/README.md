camel-xslt
===========

Some test-cases for the camel-xslt component.

This test uses the Apache Camel File component to take xml files from
src/test/resources/data and to transform them to extract the ShippingAddress
value and to put that into target/transformed-data.


