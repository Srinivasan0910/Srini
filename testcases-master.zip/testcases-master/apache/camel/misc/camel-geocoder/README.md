camel-geocoder
===========

A test-case for the camel-geocoder component. City names are read from files
stored in src/test/resources/data and then looked up via the camel-geocoder
component. The original city name/location and the retrieved latitude and
longitude are then stored in files in target/results.

