camel-weather
===========

A test-case for the camel-weather component. City names are read from files
stored in src/test/resources/data and then looked up via the camel-weather
component. The XML results are then stored in files in target/results.

