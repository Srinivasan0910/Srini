camel-pdf
===========

A test-case for the new camel-pdf component available in 2.16. XML files are
read in from src/test/resources/data and then converted to pdf, which are 
stored in target/results.

