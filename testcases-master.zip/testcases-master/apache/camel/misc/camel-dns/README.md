camel-dns
===========

A test-case for the camel-dns component. DNS names are read from files stored
in src/test/resources/data and then looked up via the camel-dns component. The
(String) results are then appended to files stored in target/results.

