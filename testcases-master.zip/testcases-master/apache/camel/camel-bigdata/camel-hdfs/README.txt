camel-hdfs
==========

This demo shows how to use Apache Camel to invoke on HDFS. The test first sets
up a mini HDFS cluster + writes a file to it. Camel is used to read the file
from HDFS and store it in target/results.

