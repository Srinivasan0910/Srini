cxf-benchmarks-jmh
===========

This project uses the JMH (http://openjdk.java.net/projects/code-tools/jmh/) to
do some micro benchmarking of some security functionality in CXF.

