cxf-timing
===========

Some timing benchmarks for CXF. When the tests are run, go into "set/etc" and do
"sh plot.sh" to generate the graphs, which are output in "target". You need to
have gnuplot installed for this.

