cxf-jaxrs-jose
===========

This project contains a number of tests that show how to use the JSON Security
functionality in Apache CXF to sign and encrypt JSON payloads to/from a 
JAX-RS service.

