cxf-jaxrs-httpsig
===========

This project contains a test that shows how to use the HTTP Signature
functionality in Apache CXF to sign a message to/from a JAX-RS service.


