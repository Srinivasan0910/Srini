cxf-asymmetric
===========

This project contains a number of tests for Asymmetric WS-Security, where it
is applied both via "actions" and also via WS-SecurityPolicy. Tests are 
included for various algorithms

